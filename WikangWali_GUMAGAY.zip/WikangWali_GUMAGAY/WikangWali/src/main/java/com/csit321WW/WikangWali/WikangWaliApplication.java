package com.csit321WW.WikangWali;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WikangWaliApplication {

	public static void main(String[] args) {
		SpringApplication.run(WikangWaliApplication.class, args);
		System.out.println("Continue working");
	}

}
