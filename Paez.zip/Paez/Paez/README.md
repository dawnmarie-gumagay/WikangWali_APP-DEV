# WIKANGWALI_APPDEV
A comprehensive collection of resources, code, and materials dedicated to the development of applications centered around the preservation, learning, or utilization of the Filipino Language. 
