package com.wikangwiz.WikangWali.Methods;

public class ResetCodeResponse {
    private String message;

    public ResetCodeResponse(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}