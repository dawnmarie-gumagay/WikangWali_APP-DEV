package com.csit321.WikangWali;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WikangWaliApplicationTests {

	@Test
	void contextLoads() {
	}

}
